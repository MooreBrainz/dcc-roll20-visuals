/*
 DCC ACTION TRACKER E08 R2 — FIVE-CRAWLER GRAPHICAL HUD TEST CANDIDATE
 Manual macros only. No character-sheet integration.
 Install E07 alone (disable E05/E06 during test). E04 is preserved.

 GM commands:
 !dcc07 add Exact Roll20 Character Name
 !dcc07 remove Exact Roll20 Character Name
 !dcc07 list
 !dcc07 anchor / resize / on / off / reposition
 !dcc07 art selected  (one-time Roll20 Library image registration)
 !dcc07 art status    (check persistent stored image reference)
 !dcc07 art https://ROLL20-IMAGE-URL  (or !dcc07 art off)
 !dcc07 round / reset / phase surprise / phase normal
 !dcc07 grant bonus / grant surprise / take bonus / take surprise
 !dcc07 restore / status / help
 Player commands, with exactly one controlled Character token selected:
 !dcc07 use / !dcc07 undo

 IMPORTANT: The approved PNG has EMPTY pip sockets and EMPTY name/round fields.
 All values and pip illumination are drawn separately by the Mod.
*/
var DCCActionTrackerE08 = DCCActionTrackerE08 || (function () {
    'use strict';
    var KEY = 'DCC_ACTION_TRACKER_E07';
    var W = 420, H = 560; // Six squares wide by eight high; artwork ratio 1086×1448
    var BASE = 2, MAX_SPECIAL = 6;
    var P = {
        gold: '#F4AF32', rim: '#FFE19A', dark: '#2A2D31',
        white: '#F8EAD2', goldText: '#FFF0CB', nameShadow: '#261012',
        nameAura: '#7B285B', plate: '#151719',
        plateEdge: '#3A3124', xRed: '#C73333', magenta: '#F634A1', cyan: '#44E4D3'
    };
    // Layout coordinates against the approved 1086 x 1448 portrait image.
    var ROW_Y = [473, 658, 845, 1033, 1217]; // calibrated from 200% Roll20 screenshot
    var PIP_X = [599, 722];
    var SPECIAL_X = [856, 979];
    var NAME_X = 320;
    var ROUND_X = 800, ROUND_Y = 281; // center the dynamic digits in the ROUND display
    // Per-row micro-adjustments from live Roll20 screenshots.
    var NAME_DY = [0, 0, 0, 8, 14];
    var PIP_DX = [15, 15, 15, 10, 12];
    var PIP_DY = [-6, 0, 6, 10, 23];
    var SURPRISE_DX = [19, 20, 22, 23, 19];
    var SURPRISE_DY = [-7, 6, 14, 14, 25];
    var BONUS_DX = [8, 8, 8, 10, 12];
    var BONUS_DY = [-6, 6, 14, 14, 25];

    function db() {
        if (!state[KEY]) {
            state[KEY] = {version: 1, roster: [], round: 1,
                phase: 'normal', imageURL: '', pages: {}};
        }
        return state[KEY];
    }
    function pageState(id) {
        var d = db();
        if (!d.pages[id]) {
            d.pages[id] = {anchor: '', visible: false, objects: []};
        }
        return d.pages[id];
    }
    function html(s) {
        return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
    function tell(pid, s) {
        var p = pid && getObj('player', pid);
        var who = p ? '"' + String(p.get('_displayname'))
            .replace(/"/g, '') + '"' : 'gm';
        sendChat('DCC E08', '/w ' + who + ' ' + s);
    }
    function charName(id) {
        var c = getObj('character', id);
        return c ? String(c.get('name')) : '[Deleted Character]';
    }
    function rosterEntry(id) {
        return db().roster.filter(function (r) {return r.id === id;})[0];
    }
    function currentPage(pid) {
        var p = getObj('player', pid), c = Campaign();
        var id = c.get('playerpageid');
        if (playerIsGM(pid)) {
            id = p && p.get('lastpage') || id;
        } else {
            id = (c.get('playerspecificpages') || {})[pid] || id;
        }
        return getObj('page', id);
    }
    function footprint(pageId) {
        var a = pageState(pageId).anchor;
        var o = a && getObj('path', a);
        return o && o.get('_pageid') === pageId ? o : null;
    }
    function shape(pageId, layer, x, y, w, h, fill, stroke, line) {
        return createObj('path', {
            _pageid: pageId, pageid: pageId, layer: layer,
            left: x, top: y, width: w, height: h,
            path: JSON.stringify([['M',0,0],['L',w,0],
                ['L',w,h],['L',0,h],['L',0,0]]),
            fill: fill, stroke: stroke, stroke_width: line || 1
        });
    }
    function circle(pageId, cx, cy, rad, fill, stroke) {
        var points = [], i, a;
        for (i=0; i<=24; i++) {
            a = Math.PI * 2 * i / 24;
            points.push([i ? 'L' : 'M', rad + rad*Math.cos(a),
                rad + rad*Math.sin(a)]);
        }
        return createObj('path', {
            _pageid: pageId, pageid: pageId, layer: 'foreground',
            left: cx, top: cy, width: rad*2, height: rad*2,
            path: JSON.stringify(points), fill: fill, stroke: stroke,
            stroke_width: 2
        });
    }
    function label(pageId, text, cx, cy, w, h, font, color, family) {
        return createObj('text', {
            _pageid: pageId, pageid: pageId, layer: 'foreground',
            left: cx, top: cy, width: w, height: h,
            text: String(text), font_size: font,
            font_family: family || 'Arial', color: color, rotation: 0
        });
    }
    function track(pageId, type, obj) {
        if (!obj) {throw new Error('Could not create '+type);}
        pageState(pageId).objects.push({id: obj.id, type: type});
        return obj;
    }
    function clear(pageId) {
        var p = pageState(pageId);
        (p.objects || []).forEach(function (r) {
            var o = getObj(r.type, r.id);
            if (o && o.get('_pageid') === pageId) {o.remove();}
        });
        p.objects = [];
    }
    function draw(pageId) {
        var p = pageState(pageId), f = footprint(pageId);
        clear(pageId);
        if (!p.visible || !f) {return;}
        var left = Number(f.get('left'))-W/2;
        var top = Number(f.get('top'))-H/2;
        var sx = W/1086, sy = H/1448;
        function X(x) {return left+x*sx;}
        function Y(y) {return top+y*sy;}
        function ink(t,x,y,w,h,size,c,font) {
            return track(pageId, 'text', label(pageId,t,X(x),Y(y),
                w*sx,h*sy,Math.max(9,Math.round(size*sy)),c,font));
        }
        // Roll20 path vertices use LOCAL pixel coordinates (not image coordinates).
        // Octagonal pips entirely cover the baked-in red X only while available.
        function octagon(x,y,w,h,cut,fill,edge) {
            var pw=w*sx, ph=h*sy, t=Math.min(cut*sx, pw*.27, ph*.27);
            var pts=[['M',t,0],['L',pw-t,0],['L',pw,t],
                ['L',pw,ph-t],['L',pw-t,ph],['L',t,ph],
                ['L',0,ph-t],['L',0,t],['L',t,0]];
            return track(pageId,'path',createObj('path',{
                _pageid:pageId,pageid:pageId,layer:'foreground',
                left:X(x),top:Y(y),width:pw,height:ph,
                path:JSON.stringify(pts),fill:fill,stroke:edge,stroke_width:2
            }));
        }
        try {
            if (db().imageURL) {
                track(pageId, 'graphic', createObj('graphic', {
                    _pageid: pageId, pageid: pageId, _subtype: 'token',
                    layer: 'foreground', imgsrc: db().imageURL,
                    left: left+W/2, top: top+H/2, width: W, height: H,
                    name: 'DCC E08 HUD SKIN', isdrawing: true, controlledby: ''
                }));
            } else {
                track(pageId,'path',shape(pageId,'foreground',left+W/2,top+H/2,
                    W,H,'#141519','#C69232',2));
                ink('DCC ACTIONS (REGISTER ART)',540,175,900,90,48,P.gold,'Arial Black');
            }
            ink(String(db().round).padStart(2,'0'),ROUND_X,ROUND_Y,
                205,90,70,P.white,'Arial Black');
            db().roster.slice(0,5).forEach(function(r,index){
                var y=ROW_Y[index], name=charName(r.id);
                var pipY=y+PIP_DY[index], pipDX=PIP_DX[index];
                var surpriseY=y+SURPRISE_DY[index], surpriseX=SPECIAL_X[0]+SURPRISE_DX[index];
                var bonusY=y+BONUS_DY[index], bonusX=SPECIAL_X[1]+BONUS_DX[index];
                if(name.length>24){name=name.slice(0,23)+'…';}
                // The API draws the name in three layers: subtle dark shadow,
                // a restrained magenta edge glow, and champagne-gold foreground.
                // Keep all three layers tied to the exact same row-specific origin.
                var nx=NAME_X+14, ny=y+NAME_DY[index];
                ink(name,nx+3,ny+4,370,100,47,P.nameShadow,'Arial Black');
                ink(name,nx,ny,370,100,48,P.nameAura,'Arial Black');
                ink(name,nx,ny,370,100,46,P.goldText,'Arial Black');
                PIP_X.forEach(function(x,i){
                    if(i<r.base){
                        // Gold octagon, inset within the graphic's bevel. The
                        // static red X remains visible when this object is absent.
                        octagon(x+pipDX,pipY,105,119,18,'#EAA62D','#FFE8A0');
                    }
                });
                if(r.surprise>0){
                    octagon(surpriseX,surpriseY,100,112,18,'#682044','#FF3DA9');
                    ink('✦',surpriseX,surpriseY,75,78,58,P.white,'Arial Black');
                    if(r.surprise>1){ink(''+r.surprise,surpriseX+49,surpriseY+33,37,35,28,P.white);}
                }
                if(r.bonus>0){
                    octagon(bonusX,bonusY,100,112,18,'#174D52','#49E7DE');
                    ink('⬡',bonusX,bonusY,75,80,55,P.cyan,'Arial Black');
                    if(r.bonus>1){ink(''+r.bonus,bonusX+45,bonusY+33,32,32,28,P.white);}
                }
            });
        } catch (e) {clear(pageId); throw e;}
    }
    function refresh() {
        Object.keys(db().pages).forEach(function (id) {
            if (getObj('page',id) && pageState(id).visible && footprint(id)) {
                draw(id);
            }
        });
    }
    function selectedCrawler(msg) {
        var s = msg.selected || [];
        if (s.length !== 1 || s[0]._type !== 'graphic') {
            throw new Error('Select exactly one crawler token.');
        }
        var t = getObj('graphic',s[0]._id);
        var pg = currentPage(msg.playerid);
        if (!t || !pg || t.get('_pageid') !== pg.id) {
            throw new Error('The selected token must be on your active map.');
        }
        var cid = t.get('represents'), c = cid && getObj('character',cid);
        var r = rosterEntry(cid);
        if (!c || !r) {
            throw new Error('The selected token must represent a registered crawler.');
        }
        if (!playerIsGM(msg.playerid)) {
            var allowed = String(c.get('controlledby')||'').split(',');
            if (allowed.indexOf(msg.playerid) < 0 &&
                allowed.indexOf('all') < 0) {
                throw new Error('You do not control this crawler.');
            }
        }
        return r;
    }
    function commands(msg) {
        if (msg.type !== 'api' || !/^!dcc07(?:\s|$)/i.test(msg.content)) {return;}
        try {
            var raw = msg.content.replace(/^!dcc07\s*/i,'').trim();
            var sep = raw.indexOf(' ');
            var cmd = (sep<0?raw:raw.slice(0,sep)).toLowerCase() || 'help';
            var arg = (sep<0?'':raw.slice(sep+1)).trim();
            var gm = playerIsGM(msg.playerid), r, pg, p, a, matches, pool;
            if (cmd === 'help') {
                tell(msg.playerid,'Players: !dcc07 use / undo (select token).<br>'+
                    'GM: add NAME, remove NAME, list, anchor, resize, on, off, reposition, ' +
                    'art selected / art status / art off, round, reset, phase surprise/normal, grant bonus/surprise, ' +
                    'take bonus/surprise, grantall surprise/bonus, encounter reset, restore, status.');
                return;
            }
            if (cmd === 'use' || cmd === 'undo') {
                r = selectedCrawler(msg);
                if (cmd === 'use') {
                    if (db().phase === 'surprise') {
                        if (r.surprise < 1) {throw new Error('No Surprise Action available.');}
                        pool = 'surprise';
                    } else if (r.bonus>0) {pool='bonus';}
                    else if (r.base>0) {pool='base';}
                    else {throw new Error('No Actions remaining.');}
                    r[pool]--;
                    r.history.push({pool:pool,round:db().round});
                } else {
                    var last = r.history[r.history.length-1];
                    if (!last || last.round !== db().round) {
                        throw new Error('No recorded Action to undo this round.');
                    }
                    r.history.pop();
                    r[last.pool]++;
                }
                refresh();
                tell(msg.playerid,html(charName(r.id))+': '+r.base+' base, '+
                    r.bonus+' bonus, '+r.surprise+' surprise.');
                return;
            }
            if (!gm) {throw new Error('GM-only command.');}
            pg = currentPage(msg.playerid);
            if (!pg) {throw new Error('No current page.');}
            p = pageState(pg.id);
            if (cmd === 'add') {
                matches = findObjs({_type:'character'}).filter(function(c) {
                    return String(c.get('name')).trim().toLowerCase()===arg.toLowerCase();
                });
                if (matches.length !== 1) {throw new Error('Need one exact unique character name. Matches: '+matches.length);}
                if (rosterEntry(matches[0].id)) {throw new Error('Crawler already registered.');}
                if (db().roster.length === 5) {throw new Error('All five roster slots are occupied.');}
                db().roster.push({id:matches[0].id,base:BASE,bonus:0,surprise:0,history:[]});
                refresh(); tell(null,'Added '+html(arg)+'.');
            } else if (cmd === 'remove') {
                r = db().roster.filter(function(x){return charName(x.id).toLowerCase()===arg.toLowerCase();})[0];
                if (!r) {throw new Error('Crawler not found in roster.');}
                db().roster = db().roster.filter(function(x){return x.id!==r.id;});
                refresh();tell(null,'Removed '+html(arg)+'.');
            } else if (cmd === 'list') {
                tell(null,db().roster.map(function(x){return html(charName(x.id))+': '+x.base+' / +'+x.bonus+' / ★'+x.surprise;}).join('<br>')||'Roster empty.');
            } else if (cmd === 'anchor') {
                if (footprint(pg.id)) {throw new Error('GM footprint exists; move it instead.');}
                var ax = Number(pg.get('width'))*35, ay = Number(pg.get('height'))*35;
                if (msg.selected && msg.selected.length === 1) {
                    var t = getObj('graphic',msg.selected[0]._id);
                    if (t && t.get('_pageid')===pg.id) {
                        ax=Number(t.get('left'));ay=Number(t.get('top'));
                    }
                }
                a = shape(pg.id,'gmlayer',ax,ay,W,H,'transparent',P.gold,3);
                if (!a) {throw new Error('Unable to create footprint.');}
                p.anchor=a.id;
                tell(null,'Created '+W+' × '+H+' GM-layer footprint (6 × 8 squares). Drag outline, then !dcc07 reposition.');
            } else if (cmd === 'resize') {
                a = footprint(pg.id);
                if (!a) {throw new Error('Create the footprint first.');}
                a.set({width: W, height: H,
                    path: JSON.stringify([['M',0,0],['L',W,0],
                        ['L',W,H],['L',0,H],['L',0,0]])});
                if (p.visible) {draw(pg.id);}
                tell(null,'Footprint resized to '+W+' × '+H+' px (6 × 8 squares); HUD refreshed.');
            } else if (cmd === 'on') {
                if (!footprint(pg.id)) {throw new Error('Create the footprint first.');}
                p.visible=true; draw(pg.id);tell(null,'HUD shown.');
            } else if (cmd === 'off') {
                p.visible=false;clear(pg.id);tell(null,'HUD hidden; footprint retained.');
            } else if (cmd === 'reposition') {
                if (!footprint(pg.id)) {throw new Error('No GM footprint on this page.');}
                if (p.visible) {draw(pg.id);}
                tell(null,'HUD repositioned to footprint centre.');
            } else if (cmd === 'art') {
                if (arg.toLowerCase() === 'status') {
                    tell(null, db().imageURL ?
                        'Roll20 artwork reference is saved in persistent Mod state. ' +
                        'Use !dcc07 on to check rendering.' :
                        'No artwork registered. Select a Roll20 Art Library copy and run !dcc07 art selected.');
                    return;
                } else if (arg.toLowerCase() === 'off') {
                    db().imageURL = '';
                } else if (arg.toLowerCase() === 'selected') {
                    var selected = msg.selected || [];
                    if (selected.length !== 1 || selected[0]._type !== 'graphic') {
                        throw new Error('Select exactly one placed HUD artwork graphic first.');
                    }
                    var artwork = getObj('graphic', selected[0]._id);
                    if (!artwork || artwork.get('_pageid') !== pg.id) {
                        throw new Error('Select the artwork on your current GM map.');
                    }
                    var source = String(artwork.get('imgsrc') || '');
                    if (!/^https:\/\//i.test(source)) {
                        throw new Error('Selected graphic does not have a usable https image source.');
                    }
                    // Roll20 normally accepts image URLs produced by its Art Library.
                    // Do not rewrite the URL: preserve the same source Roll20 provided.
                    db().imageURL = source;
                } else if (!/^https:\/\//i.test(arg)) {
                    throw new Error('Use !dcc07 art selected, !dcc07 art https://..., or !dcc07 art off.');
                } else {
                    db().imageURL = arg;
                }
                refresh();
                tell(null,'Artwork '+(db().imageURL ?
                    'configured. Verify the HUD image renders.' : 'disabled.') +
                    (arg.toLowerCase()==='selected' ?
                    ' You may remove the temporary reference graphic after verification.' : ''));
            } else if (cmd === 'encounter') {
                if (arg.toLowerCase() !== 'reset') {
                    throw new Error('Use !dcc07 encounter reset to start a fresh encounter.');
                }
                db().round = 1;
                db().phase = 'normal';
                db().roster.forEach(function(x) {
                    x.base = BASE;
                    x.bonus = 0;
                    x.surprise = 0;
                    x.history = [];
                });
                refresh();
                tell(null,'New encounter ready: Round 01, normal phase, all base Actions restored, all special Actions and undo histories cleared. Roster, art and HUD placement preserved.');
            } else if (cmd === 'round' || cmd === 'reset') {
                if (cmd === 'round') {db().round++;}
                db().phase = 'normal';
                db().roster.forEach(function(x){x.base=BASE;x.bonus=0;x.surprise=0;x.history=[];});
                refresh();tell(null,'Round '+db().round+': standard pips refilled; specials cleared.');
            } else if (cmd === 'phase') {
                if (arg !== 'normal' && arg !== 'surprise') {throw new Error('Use phase normal or phase surprise.');}
                db().phase=arg;tell(null,'Combat phase: '+arg+'.');
            } else if (cmd === 'grant' || cmd === 'take') {
                if (arg !== 'bonus' && arg !== 'surprise') {throw new Error('Choose bonus or surprise.');}
                r=selectedCrawler(msg);
                if (cmd === 'grant') {
                    if (r[arg] >= MAX_SPECIAL) {throw new Error('Maximum special Actions: '+MAX_SPECIAL);}
                    r[arg]++;
                } else {
                    if (r[arg]===0) {throw new Error('No '+arg+' Action to remove.');}
                    r[arg]--;
                }
                refresh();tell(null,html(charName(r.id))+' '+arg+': '+r[arg]);
            } else if (cmd === 'grantall') {
                if (arg !== 'surprise' && arg !== 'bonus') {
                    throw new Error('Use !dcc07 grantall surprise or !dcc07 grantall bonus.');
                }
                var granted = 0, capped = 0;
                db().roster.forEach(function(x){
                    if (x[arg] < MAX_SPECIAL) { x[arg]++; granted++; }
                    else { capped++; }
                });
                refresh();
                tell(null,'Granted +1 '+html(arg)+' Action to '+granted+
                    ' registered crawler(s).'+(capped ? ' '+capped+' at the cap.' : '')); 
            } else if (cmd === 'restore') {
                r=selectedCrawler(msg);
                if (r.base>=BASE) {throw new Error('Standard Actions are already full.');}
                r.base++;refresh();tell(null,html(charName(r.id))+' restored to '+r.base+' base Actions.');
            } else if (cmd === 'status') {
                tell(null,'E07 / Round '+db().round+' / Phase '+db().phase+
                    ' / Roster '+db().roster.length+'/5 / artwork '+(db().imageURL?'set':'none')+
                    ' / anchor '+(footprint(pg.id)?'yes':'no')+' / visible '+p.visible+'.');
            } else {throw new Error('Unknown command. Run !dcc07 help.');}
        } catch (e) {
            log('DCC E08 error: '+(e.stack||e));
            tell(msg.playerid,'<b>E08:</b> '+html(e.message||e));
        }
    }
    on('ready',function(){db();on('chat:message',commands);log('DCC Action Tracker E08 R6 test candidate ready (champagne-gold layered name treatment).');});
    return {};
}());
