# DCC Action Tracker E08 R6 — Champagne Names Test Candidate

## Scope

- Preserves all E08 R5 positioning offsets, including the most recent row-4 Surprise/Bonus upward correction.
- Gives each registered player name a restrained three-layer effect: dark offset shadow, magenta edging, champagne-gold face.
- No changes to action logic, commands, HUD size or art registration.
- Retains GM commands `!dcc07 grantall bonus`, `!dcc07 grantall surprise`, and `!dcc07 encounter reset`.

## Install

1. Disable E08 R5; install **DCC_Action_Tracker_E08_R6.js** as the sole running E08 script.
2. Restart the Roll20 Mod sandbox.
3. Run `!dcc07 reposition` to redraw. The roster, art registration and footprint remain in persistent state.
4. Test at 200% to inspect names and at 75% to confirm practical readability.

## Hands-on checks

1. Verify that row 4 Surprise and Bonus pips remain in their R5 locations.
2. Verify all five player names remain at their exact R5 positions and are legible in champagne gold.
3. Spend and undo a standard Action to verify dynamic red-X exposure is unchanged.
4. Test `!dcc07 grantall bonus`, `!dcc07 grantall surprise` and `!dcc07 encounter reset`.

This is a test candidate, not promoted or live validated. Layered Roll20 text may render with different edges than a true blur/glow; inspect the in-game result before accepting.
